package com.example.audioplayer

import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.provider.MediaStore.Video.Media
import android.util.Log
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.musicplayer.AudioViewModel
import com.example.musicplayer.R
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.util.Timer
import kotlin.time.TimeMark

class PlayerActivity : AppCompatActivity() {

    //    Runnable and Handler for seekbar
    private lateinit var runnable: Runnable
    private var handler=Handler()

    //    Making mediaplayer static to make it a song to pause once we go back and play new song
    companion object {
        var mediaPlayer:MediaPlayer?=null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_music_player)
        val seekBar:SeekBar=findViewById(R.id.seekBar)

        val audioViewModel: AudioViewModel.SongData =ViewModelProvider(this).get(AudioViewModel.SongData::class.java)

        var id =intent.getStringExtra("id")!!.toInt()
        var song:Song=audioViewModel.songs.get(0)
        var index=0
        for(i in 0 until audioViewModel.songs.size){
            if(audioViewModel.songs.get(i).id==id){
                song=audioViewModel.songs.get(i)
                index=i
            }
        }

//        Condition to make prev song from stop playing
        if(mediaPlayer!=null)
        {
            mediaPlayer?.stop()
            mediaPlayer?.reset()
            mediaPlayer?.release()
            mediaPlayer=null
        }

//        Fetching layout attributes
        val thumbnailplayer = findViewById<ImageView>(R.id.thumbnail)
        val titleplayer = findViewById<TextView>(R.id.titleplayer)
        val artistplayer = findViewById<TextView>(R.id.artistplayer)
        val timeleft = findViewById<TextView>(R.id.timeleft)
        val timeright = findViewById<TextView>(R.id.timeright)
        val playbutton = findViewById<FloatingActionButton>(R.id.playbutton)
        val previousbutton = findViewById<FloatingActionButton>(R.id.previousbutton)
        val nextbutton = findViewById<FloatingActionButton>(R.id.nextbutton)


        //        Added main functionalities in a function so we can call it afterwards also
        fun mainPlayer(song:Song) {

            mediaPlayer=MediaPlayer.create(this,song.audio)
            mediaPlayer?.start()

            thumbnailplayer.setImageResource(song.thumbnail)
            titleplayer.text = song.songName
            artistplayer.text = song.artistName
            seekBar.progress = 0
            seekBar.max = mediaPlayer!!.duration

//            Playing and pausing songs
            playbutton.setOnClickListener {
                if (!mediaPlayer!!.isPlaying) {
                    mediaPlayer?.start()
                    playbutton.setImageResource(R.drawable.ic_baseline_pause_circle_filled_24)
                } else {
                    mediaPlayer?.pause()
                    playbutton.setImageResource(R.drawable.ic_baseline_play_circle_filled_24)
                }
            }

            //Setting seekbar with song length
            seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(p0: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        mediaPlayer?.seekTo(progress)
                    }
                    val p1_sec = (progress / 1000)
                    val p1_minute = (p1_sec / 60)
                    val p1_second = p1_sec % 60
                    timeleft.text = p1_minute.toString() + ":" + p1_second.toString()

                    val p1_DurSec = (seekBar.max / 1000)
                    val p1_min = (p1_DurSec / 60)
                    val p1_secd = p1_DurSec % 60
                    timeright.text = p1_min.toString() + ":" + p1_secd.toString()
                }

                override fun onStartTrackingTouch(p0: SeekBar?) {
                }

                override fun onStopTrackingTouch(p0: SeekBar?) {
                }
            })

            runnable = Runnable {
                seekBar.progress = mediaPlayer!!.currentPosition
                handler.postDelayed(runnable, 1000)
            }
            handler.postDelayed(runnable, 1000)
            mediaPlayer?.setOnCompletionListener {
                mediaPlayer?.pause()
                playbutton.setImageResource(R.drawable.ic_baseline_pause_circle_filled_24)
            }
        }
        mainPlayer(song)

//        change to next song
        nextbutton.setOnClickListener {
            mediaPlayer?.stop()
            mediaPlayer?.release()

            if(index>=(audioViewModel.songs.size-1))
            {
                index=0
            }
            else
            {
                index++;
            }
            song= audioViewModel.songs.get(index)
            mainPlayer(song)
        }
//        change to prev song
        previousbutton.setOnClickListener {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            if(index<=0)
            {
                index=audioViewModel.songs.size-1
            }
            else
            {
                index--;
            }
            song = audioViewModel.songs.get(index)
            mainPlayer(song)
        }

    }
}