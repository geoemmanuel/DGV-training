package com.example.musicplayer

import androidx.lifecycle.ViewModel
import com.example.audioplayer.Song

class AudioViewModel {

class SongData: ViewModel(){

    var songs = listOf<Song>(
        Song(1,"Bad Habits","Ed Sheeran",R.drawable.badhabits,R.raw.badhabits,"pop"),
        Song(2,"demons","Fawlin XAM",R.drawable.demons,R.raw.demons,"lofi"),
        Song(3,"Chlorine","Twenty One Pilots",R.drawable.chlorine,R.raw.chlorine,"pop"),
        Song(4,"Mount Everest","Labrinth",R.drawable.labrinth,R.raw.mounteverest,"gaming"),
        Song(5,"Do i Wanna Know","Artic Monkeys",R.drawable.articmonkeys,R.raw.doiwannaknow,"gaming"),

        Song(6,"16","Baby keem",R.drawable.babykeem,R.raw.sixteen,"pop"),
        Song(7,"Claws","Charli XCX",R.drawable.charliclaws,R.raw.clawscharli,"madeforyou"),

    )

    var genre = listOf<String>(
        "madeforyou",
        "gaming",
        "lofi",
        "pop"

    )

}
    }
