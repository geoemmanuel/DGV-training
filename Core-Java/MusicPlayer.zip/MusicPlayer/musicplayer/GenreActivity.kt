package com.example.audioplayer

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.constraintlayout.widget.ConstraintLayout
import com.example.musicplayer.R

class GenreActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_genre)
        var genre1 = findViewById<ConstraintLayout>(R.id.genre1)
        genre1.setOnClickListener(){
            val intent = Intent(GenreActivity@this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}